<?php

namespace App\Http\Controllers\Frontend;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\ProductRepository;
use App\Repositories\NewsRepository;
use SEO;

class HomeController extends Controller
{
    protected $product_hot;
    protected $news_hot;

    public function __construct(ProductRepository $product_hot, NewsRepository $news_hot)
    {
        $this->product_hot = $product_hot;
        $this->news_hot = $news_hot;
    }

    public function index()
    {
        SEO::setTitle('Home');
        SEO::setDescription('This is my page description');
        SEO::opengraph()->setUrl('http://localhost/book/');
        SEO::setCanonical('https://codecasts.com.br/lesson');
        SEO::opengraph()->addProperty('type', 'articles');
        SEO::twitter()->setSite('@LuizVinicius73');

        $products = $this->product_hot->listProductHot();
        $news = $this->news_hot->listNewsHot();

       return view('frontend.home.index', compact('products', 'news'));
    }
}
